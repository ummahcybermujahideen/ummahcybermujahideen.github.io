# Information About CMSBrute & Auto Shell

This Tool Created For Black Hat Purposes. I Don't Aspect Any Responsibility For Illegal Ussess
Tool Have 6 CMS Brute Force Whois:
1. Wordpress
2. Joomla
3. Opencart 
4. Drupal
5. osCommerce
6. Magento

# AutoShell Support:

3 CMS Login & AUTO shell Support, They Are:
1. Wordpress ( Direct PHP Upload, Plugin Zip, Theme Edit, Theme Upload)
2. Joomla Template Shell
3. Opencart Priv8 Bypass Extension Shell

# Tool File Directory & File

You Can See The Folder, Name is "files" .
The files directory have: Opencart Shell Extension Zip & Wp Plugin File Zip , Skip Them .
You can find in "files" directory , some importan file.
They Are:
1. passwords.txt
2. joomla-users.txt
3. opencart-users.txt
4. drupal-users.txt
5. othere-users.txt

# File passwords.txt

In this file have "333" line passwords. You can add more password or remove
If you need fast, remove some line password.
If you have rdp then add more in list

# File *-users.txt

The mean of *-users.txt is Anything-users.txt
joomla-users.txt , opencart-users.txt example

Custom Users Add:
1. You Can add Joomla Custom users in joomla-users.txt
2. You Can add Opencart Custom users in opencart-users.txt
3. You can add Drupal custom users in drupal-users.txt
5. You can add Magento , osCommerce User in othere-users.txt

You Thinking Now , Where is Wordpress. Bro , In Wordpress Don't need add users
Tool Automatic, Grab username from site . Good Feautures

Tool Support Python 2.7 - 3.9 Versions.
Tool Version: CB 1.0
Tool Author: @Salahdin1337 
Multiprocess: Yeah, Tool Is Too Fast.

./Black_Phish

